# FaceRecognition
人脸识别打卡系统

- 使用技术: qt + opencv + mysql/sqlite
- 使用说明: /docs/人脸识别打卡系统使用说明.pdf
- 联系方式：
	- IT项目交流群-2群： 946286053
	- IT项目交流群-1群： 245022761